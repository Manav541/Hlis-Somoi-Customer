interface ApiHeaderType {
  'api-key': string;
  'Content-Type': string;
  'accept-language': string;
  token?: string;
}

interface MakeServerRequestType {
  navigation: any;
  method: string;
  apiEndPoint: string;
  params: object | null;
  callback: (
    data: object | string | null,
    error?: {code?: number; message: string},
  ) => void;
  showLoader?: boolean;
  isDebug?: boolean;
}

function handleOnUnauthorizedError(
  navigation: any,
  callback: (data: any, error?: {message: string}) => void,
) {
  //   AsyncStorageManager.clearAll();
  //   navigation.dispatch(
  //     CommonActions.reset({
  //       index: 0,
  //       routes: [{name: 'WalkthroughContainer'}],
  //     }),
  //   );
  callback(null, {message: 'Session expired'});
}

const APIManager = {
  getURL: (endpoint: string) => {
    return ApiBaseURL.development + endpoint;
  },

  getHeader: (): ApiHeaderType => {
    const acceptLang: string =
      AsyncStorageManager.getItem(AsyncStorageKeys.USER_SEL_LANG_CODE) || 'en';

    return {
      'api-key': '',
      'Content-Type': 'text/plain',
      'accept-language': acceptLang,
    };
  },

  encryptData: (encryptData: string | object) => {
    return CryptoJS.AES.encrypt(JSON.stringify(encryptData), SECRET, {
      iv: ENC_IV,
    }).toString();
  },

  decryptData: (decryptData: string | object) => {
    return JSON.parse(
      CryptoJS.AES.decrypt(decryptData, SECRET, {iv: ENC_IV}).toString(
        CryptoJS.enc.Utf8,
      ),
    );
  },

  makeServerRequest:
    async () =>
    ({
      navigation,
      method,
      apiEndPoint,
      params = null,
      callback,
      showLoader = true,
      isDebug = true,
    }: MakeServerRequestType) => {
      const netInfo = await NetInfo.fetch();
      if (!netInfo.isConnected) {
        callback(null, {code: 97, message: 'Internet connection lost'});
        return;
      }

      if (showLoader) {
        toggleLoader(true);
      }

      const header = APIManager.getHeader();
      const userToken = AsyncStorageManager.getItem(
        AsyncStorageKeys.USER_TOKEN,
      );

      let dataToSend: string | null = null;

      if (userToken) {
        header.token = APIManager.encryptData(userToken);
      }

      if (params) {
        dataToSend = APIManager.encryptData(params);
      }

      const axiosConfig = {headers: header};

      if (isDebug) {
        __DEV__ &&
          console.log(
            '🚀🚀🚀 <========= API Request Log Start =========> 🚀🚀🚀',
          );
        __DEV__ &&
          console.log(
            'Method & URL : ',
            method,
            APIManager.getURL(apiEndPoint),
          );
        __DEV__ && console.log('Original Data==>', params);
        __DEV__ && console.log('Encrypted Data==>', dataToSend);
        __DEV__ && console.log('Header==>', axiosConfig);
      }

      try {
        let response;

        if (method === MethodType.GET) {
          if (isDebug) {
            __DEV__ && console.log('Get Method');
          }
          response = await axios.get(
            APIManager.getURL(apiEndPoint),
            axiosConfig,
          );
        } else {
          if (isDebug) {
            __DEV__ && console.log('Post Method');
          }
          response = await axios.post(
            APIManager.getURL(apiEndPoint),
            dataToSend,
            axiosConfig,
          );
        }
        __DEV__ && console.log('Response==>', response.data);

        if (response.status === 200) {
          const responseData = APIManager.decryptData(response.data);
          if (isDebug) {
            __DEV__ && console.log('Original Response==>', response.data);
            __DEV__ &&
              console.log(
                'Decrypted Response==>',
                JSON.stringify(responseData),
              );
            __DEV__ &&
              console.log(
                '🚀🚀🚀 <========= API Request Log End =========> 🚀🚀🚀',
              );
          }
          if (showLoader) {
            toggleLoader(false);
          }
          if (responseData.code === StatusCode.USER_SESSION_EXPIRE) {
            handleOnUnauthorizedError(navigation, callback);
          } else {
            callback(responseData);
          }
        } else if (response.status === 401) {
          handleOnUnauthorizedError(navigation, callback);
          if (showLoader) {
            toggleLoader(false);
          }
        } else {
          callback(null, {message: 'Unknown error'});
          if (showLoader) {
            toggleLoader(false);
          }
        }
      } catch (error: any) {
        if (error?.response?.status === 401) {
          handleOnUnauthorizedError(navigation, callback);
        }

        if (showLoader) {
          toggleLoader(false);
        }
        __DEV__ &&
          console.log(`Error while calling ${apiEndPoint} API==>`, error);
        callback(null, {message: error.message || 'Request failed'});
      }
    },
};
