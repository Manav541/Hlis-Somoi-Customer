const common = require("../utils/common");
const admin = require("firebase-admin");
const { mapObject } = require("underscore");
const service = require("./somoi-3c4b0-firebase-adminsdk-fbsvc-adcfb015fb.json");
const conn = require("./database");
const moment = require("moment");
const path = require("path");
const GLOBALS = require("./constants");

admin.initializeApp({
  credential: admin.credential.cert(service),
});

const sendSinglePush = async (params, user) => {
  try {
    let query;

    if (user == "customer") {
      query = `SELECT customer_id as receiver_id, device_token , device_type FROM customer.tbl_customer_device WHERE customer_id = ${params.receiver_id};`;
    } else if (user == "driver") {
      query = `SELECT driver_id as receiver_id, device_token , device_type FROM driver.tbl_driver_device WHERE driver_id = ${params.receiver_id};`;
    } else if (user == "admin") {
      query = `SELECT id as receiver_id, device_token  FROM admin.tbl_admin WHERE id = ${params.receiver_id};`;
    } else {
      query = `SELECT vendor_id as receiver_id, device_token , device_type FROM vendor.tbl_vendor_device WHERE vendor_id = ${params.receiver_id};`;
    }

    const result = await conn.query(query, []);

    let userDetails = result.rows[0];

    params.receiver_id = userDetails.receiver_id;

    let sendPush = true;

    if (params?.isInsert) {
      let insertData = {
        sender_id: params.sender_id,
        sender_type: params.sender_type || "system",
        receiver_id: params.receiver_id,
        title: params.title,
        body: params.body,
        ref_id: params.ref_id,
        ref_tbl_name: params.ref_tbl_name,
        is_action: params.is_action || 0,
        // notification_type: params.notification_type,
        tag: params.tag,
        is_read: params.is_read || 0,
        other_data: JSON.stringify(params?.other_data) || "{}",
      };
      if (user == "customer") {
        await common.singleInsert("customer.tbl_notifications", insertData);
      } else if (user == "driver") {
        await common.singleInsert("driver.tbl_notifications", insertData);
      } else if (user == "admin") {
        await common.singleInsert("admin.tbl_notifications", insertData);
      } else {
        await common.singleInsert("vendor.tbl_notifications", insertData);
      }
    }

    if (sendPush && userDetails?.device_token?.length > 0) {
      params.other_data =
        mapObject(params?.other_data, (value) => String(value)) || {};

      let message;

      if (user == "admin") {
        message = {
          notification: {
            title: params.title.toString(),
            body: params.body.toString(),
          },
          data: {
            title: params.title.toString(),
            message: params.body.toString(),
            tag: params.tag.toString(),
            sender_type: params.sender_type || "system",
            ...params?.other_data,
          },
          apns: {
            payload: {
              aps: {
                sound: "default",
              },
            },
            headers: {
              "apns-priority": "10",
            },
          },
          token: userDetails.device_token,
        };
      } else {
        if (userDetails.device_type == "A") {
          message = {
            token: userDetails.device_token,

            data: {
              data: JSON.stringify({
                title: params.title.toString(),
                message: params.body.toString(),
                notification_tag: params.tag.toString(),
                sender_type: params.sender_type || "system",
                body: params.body.toString(),
                ...params?.other_data,
              }),
              notification_tag: params.tag ? params.tag.toString() : "",
            },
            android: {
              priority: "high",
            },
            apns: {
              payload: {
                aps: {
                  contentAvailable: 1,
                  mutableContent: 1, // Important, without this the extension won't fire
                  alert: {
                    title: params.title.toString(),
                    body: params.body.toString(),
                  },
                },
              },
            },
          };
        } else {
          message = {
            token: userDetails.device_token,
            notification: {
              title: params.title.toString(),
              body: params.body.toString(),
            },
            data: {
              title: params.title.toString(),
              body: params.body.toString(),
              notification_tag: params.tag ? params.tag.toString() : "",
              sender_type: params.sender_type || "system",
              body: params.body.toString(),
              ...params?.other_data,
            },
            apns: {
              payload: {
                aps: {
                  sound: "default",
                },
              },
            },
          };
        }
      }

      try {
        await admin.messaging().send(message);
        console.log(
          `Notification sent successfully regarding ${user} with tag : ${params.tag} and title : ${params.title}`
        );
        return { status: true, message: "Notification sent successfully" };
      } catch (e) {
        console.error(
          `Error sending notification regarding ${user} with tag : ${params.tag} and title : ${params.title}: `,
          e
        );
        return { status: false, message: e };
      }
    } else {
      console.error(
        `No device token found or push not sent regarding ${user} with tag : ${params.tag} and title : ${params.title}`
      );
      return { status: false, message: "Notification not sent" };
    }
  } catch (e) {
    console.error(
      `Error sending notification regarding ${user} with tag : ${params.tag} and title : ${params.title}: `,
      e
    );
    return { status: false, message: e };
  }
};

module.exports = { sendSinglePush };
